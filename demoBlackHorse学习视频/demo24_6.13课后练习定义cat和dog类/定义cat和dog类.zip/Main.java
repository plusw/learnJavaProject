public class Main{
	public static void main(String[] args){
		Cat myCat=new Cat("花色","波斯");
		Dog myDog=new Dog("黑色","藏獒");
		
		myCat.eat();
		myCat.catchMouse();
		myDog.eat();
		myDog.lookHome();
	}
}
	