## UUID
UUID 可以生成一个随机且唯一的值,可以方便文件不重名的命名
```java
UUID uuid =UUID.randomUUID();
String s=uuid.toString();
System.out.println(s);//打印结果为  c360122b-60c6-4df3-a5f1-436f9849c6e6
```
