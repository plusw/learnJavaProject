## for循环

for(String s : list){ System.out.println(s)};