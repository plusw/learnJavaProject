## question
6.19  java不用ide如何导包？     
```diff
! 未解决
```

7.10 多线程Callable<String>接口中有个"String"泛型是什么？
```diff
! 未解决
```
