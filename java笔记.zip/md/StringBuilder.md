## StringBuilder
StringBuilder sb=new StringBuilder();
sb.append("abc");//字符串拼接

StringBuilder常用方法:

sb.append(a);

sb.reverse()//字符串倒过来（取反）

sb.length()；

sb.toString();

sb.replace(1,2,"a");//根据索引替换

StringBuilder("abc");//String转StringBuilder

StringBulider是可变的，可以提供字符串操作效率