## HashMap
##### 判断key是否存在
HashMap<Integer, String> sites = new HashMap<>();
if(sites.containsKey(1)) {
   System.out.println("key 为 1 存在于 sites 中");
}
